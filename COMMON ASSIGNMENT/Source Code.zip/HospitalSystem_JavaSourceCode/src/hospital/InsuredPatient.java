package hospital;

/** Insured patients pay only the co-pay percentage; the rest is covered by insurance. */
public class InsuredPatient extends Patient {
    private final double coPayPercentage;
    private final String insuranceProvider;

    public InsuredPatient(String id, String name, int age, String contactNumber,
                           String insuranceProvider, double coPayPercentage) {
        super(id, name, age, contactNumber);
        this.insuranceProvider = insuranceProvider;
        this.coPayPercentage = coPayPercentage;
    }

    public String getInsuranceProvider() { return insuranceProvider; }

    @Override
    public double calculateConsultationFee() {
        return getBaseConsultationFee() * coPayPercentage;
    }

    @Override
    public String getCategory() {
        return "Insured (" + insuranceProvider + ")";
    }
}

package hospital;

public class LowStockNotification extends Notification {
    private final Medicine medicine;

    public LowStockNotification(Medicine medicine) {
        super();
        this.medicine = medicine;
    }

    @Override
    public String send() {
        return String.format("[LOW STOCK ALERT] %s is at %d units (reorder threshold: %d). Please restock.",
                medicine.getName(), medicine.getStockQuantity(), medicine.getReorderThreshold());
    }
}

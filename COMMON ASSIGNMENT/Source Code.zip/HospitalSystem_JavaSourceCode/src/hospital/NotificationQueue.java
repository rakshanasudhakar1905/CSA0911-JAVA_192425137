package hospital;

import java.util.LinkedList;
import java.util.Queue;

/**
 * A hand-rolled thread-safe producer/consumer queue built with wait()/notifyAll()
 * to explicitly demonstrate inter-thread communication (CO3), rather than hiding
 * it behind java.util.concurrent.BlockingQueue.
 */
public class NotificationQueue {
    private final Queue<Notification> queue = new LinkedList<>();
    private volatile boolean shutdown = false;

    /** Producer side: called by booking / stock-check logic. */
    public synchronized void enqueue(Notification notification) {
        queue.add(notification);
        notifyAll();               // wake any waiting consumer thread
    }

    /**
     * Consumer side: blocks (releasing the lock via wait()) until a notification is
     * available or the queue is shut down.
     */
    public synchronized Notification dequeue() throws InterruptedException {
        while (queue.isEmpty() && !shutdown) {
            wait();                 // releases lock, sleeps until notifyAll()
        }
        if (queue.isEmpty() && shutdown) {
            return null;
        }
        return queue.poll();
    }

    public synchronized void shutdown() {
        shutdown = true;
        notifyAll();
    }
}

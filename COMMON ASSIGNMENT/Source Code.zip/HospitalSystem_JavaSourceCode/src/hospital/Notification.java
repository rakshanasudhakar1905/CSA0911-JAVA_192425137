package hospital;

/**
 * Abstract Notification. ReminderNotification and LowStockNotification override
 * send() so notification *behaviour* (recipient, message, channel) adapts at run
 * time depending on the concrete notification type — polymorphism applied to the
 * alerting subsystem, independent from the Patient/Medicine hierarchies.
 */
public abstract class Notification {
    private final String createdAt;

    public Notification() {
        this.createdAt = java.time.LocalDateTime.now().toString();
    }

    public String getCreatedAt() { return createdAt; }

    /** Concrete subclasses format and "dispatch" (here: print) their own message. */
    public abstract String send();
}

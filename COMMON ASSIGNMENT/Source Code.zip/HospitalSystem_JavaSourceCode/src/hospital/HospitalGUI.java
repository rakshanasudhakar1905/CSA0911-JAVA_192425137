package hospital;

import hospital.exceptions.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Smart Hospital Patient Appointment, Pharmacy Inventory
 * and Alert Notification System
 *
 * GUI layer implemented using Java Swing.
 */
public class HospitalGUI extends JFrame {

    private final HospitalService service;
    private final NotificationQueue notificationQueue;

    private JTextArea outputArea;
    private JLabel statusLabel;

    public HospitalGUI(HospitalService service,
                       NotificationQueue notificationQueue) {

        this.service = service;
        this.notificationQueue = notificationQueue;

        setTitle("Smart Hospital Management System");
        setSize(1150, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        createGUI();
    }

    // ============================================================
    // MAIN GUI
    // ============================================================

    private void createGUI() {

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // ---------------- HEADER ----------------

        JPanel header = new JPanel(new BorderLayout());
        header.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel(
                "SMART HOSPITAL MANAGEMENT SYSTEM",
                SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 26));

        JLabel subtitle = new JLabel(
                "Patient Appointment • Pharmacy • Notifications",
                SwingConstants.CENTER
        );

        subtitle.setFont(new Font("Arial", Font.PLAIN, 14));

        JPanel heading = new JPanel(new GridLayout(2, 1));
        heading.add(title);
        heading.add(subtitle);

        header.add(heading, BorderLayout.CENTER);

        // ---------------- MENU ----------------

        JPanel menuPanel = new JPanel(new GridLayout(0, 1, 5, 5));

        JButton dashboardButton =
                createButton("Dashboard");

        JButton patientButton =
                createButton("Register Patient");

        JButton doctorButton =
                createButton("View Doctors");

        JButton appointmentButton =
                createButton("Book Appointment");

        JButton cancelButton =
                createButton("Cancel Appointment");

        JButton searchButton =
                createButton("Search Patient");

        JButton inventoryButton =
                createButton("View Pharmacy");

        JButton medicineButton =
                createButton("Dispense Medicine");

        JButton notificationButton =
                createButton("Notifications");

        JButton patientReportButton =
                createButton("Patient Visit Report");

        JButton inventoryReportButton =
                createButton("Inventory Report");

        JButton concurrencyButton =
                createButton("Concurrency Demo");

        JButton clearButton =
                createButton("Clear Output");

        menuPanel.add(dashboardButton);
        menuPanel.add(patientButton);
        menuPanel.add(doctorButton);
        menuPanel.add(appointmentButton);
        menuPanel.add(cancelButton);
        menuPanel.add(searchButton);
        menuPanel.add(inventoryButton);
        menuPanel.add(medicineButton);
        menuPanel.add(notificationButton);
        menuPanel.add(patientReportButton);
        menuPanel.add(inventoryReportButton);
        menuPanel.add(concurrencyButton);
        menuPanel.add(clearButton);

        // ---------------- OUTPUT ----------------

        outputArea = new JTextArea();

        outputArea.setEditable(false);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);

        JScrollPane scrollPane =
                new JScrollPane(outputArea);

        // ---------------- STATUS ----------------

        statusLabel =
                new JLabel("System Ready");

        statusLabel.setBorder(
                new EmptyBorder(5, 5, 5, 5)
        );

        // ---------------- EVENTS ----------------

        dashboardButton.addActionListener(e ->
                showDashboard());

        patientButton.addActionListener(e ->
                registerPatient());

        doctorButton.addActionListener(e ->
                viewDoctors());

        appointmentButton.addActionListener(e ->
                bookAppointment());

        cancelButton.addActionListener(e ->
                cancelAppointment());

        searchButton.addActionListener(e ->
                searchPatient());

        inventoryButton.addActionListener(e ->
                viewInventory());

        medicineButton.addActionListener(e ->
                dispenseMedicine());

        notificationButton.addActionListener(e ->
                showNotifications());

        patientReportButton.addActionListener(e ->
                showPatientReport());

        inventoryReportButton.addActionListener(e ->
                showInventoryReport());

        concurrencyButton.addActionListener(e ->
                runConcurrencyDemo());

        clearButton.addActionListener(e ->
                outputArea.setText(""));

        // ---------------- LAYOUT ----------------

        mainPanel.add(header, BorderLayout.NORTH);
        mainPanel.add(menuPanel, BorderLayout.WEST);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        add(mainPanel);

        showDashboard();
    }

    private JButton createButton(String text) {

        JButton button = new JButton(text);

        button.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        button.setFocusPainted(false);

        return button;
    }

    // ============================================================
    // DASHBOARD
    // ============================================================

    private void showDashboard() {

        StringBuilder sb = new StringBuilder();

        sb.append("\n");
        sb.append("===============================================\n");
        sb.append("       SMART HOSPITAL DASHBOARD\n");
        sb.append("===============================================\n\n");

        sb.append("Patients Registered : ")
                .append(service.getPatients().size())
                .append("\n");

        sb.append("Doctors Registered  : ")
                .append(service.getDoctors().size())
                .append("\n");

        sb.append("Medicines Available : ")
                .append(service.getInventory().size())
                .append("\n");

        sb.append("Appointments        : ")
                .append(service.getAppointments().size())
                .append("\n");

        sb.append("\n-----------------------------------------------\n");
        sb.append("SYSTEM MODULES\n");
        sb.append("-----------------------------------------------\n");

        sb.append("1. Patient Management\n");
        sb.append("2. Doctor Management\n");
        sb.append("3. Appointment Management\n");
        sb.append("4. Pharmacy Inventory\n");
        sb.append("5. Notification System\n");
        sb.append("6. Patient Visit Reports\n");
        sb.append("7. Inventory Reports\n");
        sb.append("8. Multithreaded Booking\n");

        sb.append("\n===============================================\n");

        display(sb.toString());
    }

    // ============================================================
    // REGISTER PATIENT
    // ============================================================

    private void registerPatient() {

        try {

            JTextField idField =
                    new JTextField();

            JTextField nameField =
                    new JTextField();

            JTextField ageField =
                    new JTextField();

            JTextField contactField =
                    new JTextField();

            String[] categories = {
                    "General",
                    "Senior Citizen",
                    "Insured"
            };

            JComboBox<String> categoryBox =
                    new JComboBox<>(categories);

            JPanel panel = new JPanel(
                    new GridLayout(0, 2, 5, 5)
            );

            panel.add(new JLabel("Patient ID:"));
            panel.add(idField);

            panel.add(new JLabel("Name:"));
            panel.add(nameField);

            panel.add(new JLabel("Age:"));
            panel.add(ageField);

            panel.add(new JLabel("Contact:"));
            panel.add(contactField);

            panel.add(new JLabel("Category:"));
            panel.add(categoryBox);

            int result = JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    "Register Patient",
                    JOptionPane.OK_CANCEL_OPTION
            );

            if (result != JOptionPane.OK_OPTION)
                return;

            String id =
                    idField.getText().trim();

            String name =
                    nameField.getText().trim();

            int age =
                    Integer.parseInt(ageField.getText().trim());

            String contact =
                    contactField.getText().trim();

            if (id.isEmpty() ||
                    name.isEmpty() ||
                    contact.isEmpty()) {

                throw new InvalidInputException(
                        "All fields are required."
                );
            }

            Patient patient;

            String category =
                    (String) categoryBox.getSelectedItem();

            if ("Senior Citizen".equals(category)) {

                patient =
                        new SeniorCitizenPatient(
                                id,
                                name,
                                age,
                                contact
                        );

            } else if ("Insured".equals(category)) {

                String provider =
                        JOptionPane.showInputDialog(
                                this,
                                "Insurance Provider:"
                        );

                String copayText =
                        JOptionPane.showInputDialog(
                                this,
                                "Co-pay fraction (example: 0.30):"
                        );

                double copay =
                        Double.parseDouble(copayText);

                patient =
                        new InsuredPatient(
                                id,
                                name,
                                age,
                                contact,
                                provider,
                                copay
                        );

            } else {

                patient =
                        new GeneralPatient(
                                id,
                                name,
                                age,
                                contact
                        );
            }

            service.registerPatient(patient);

            display(
                    "\nPATIENT REGISTERED SUCCESSFULLY\n" +
                    "--------------------------------\n" +
                    patient.getSummary()
            );

            statusLabel.setText(
                    "Patient registered: " + id
            );

        } catch (NumberFormatException e) {

            showError(
                    "Age / co-pay must be a valid number."
            );

        } catch (InvalidInputException e) {

            showError(e.getMessage());
        }
    }

    // ============================================================
    // VIEW DOCTORS
    // ============================================================

    private void viewDoctors() {

        StringBuilder sb = new StringBuilder();

        sb.append("\n");
        sb.append("=============== DOCTORS ===============\n\n");

        for (Doctor doctor :
                service.getDoctors().values()) {

            sb.append("Doctor ID     : ")
                    .append(doctor.getId())
                    .append("\n");

            sb.append("Doctor Name   : Dr. ")
                    .append(doctor.getName())
                    .append("\n");

            sb.append("Specialization: ")
                    .append(doctor.getSpecialization())
                    .append("\n");

            sb.append("Slots Left    : ")
                    .append(doctor.getAvailableSlots())
                    .append("\n");

            sb.append("Waitlist      : ")
                    .append(doctor.getWaitlist().size())
                    .append("\n");

            sb.append("---------------------------------------\n");
        }

        display(sb.toString());
    }

    // ============================================================
    // BOOK APPOINTMENT
    // ============================================================

    private void bookAppointment() {

        try {

            JTextField patientField =
                    new JTextField();

            JTextField doctorField =
                    new JTextField();

            JPanel panel =
                    new JPanel(new GridLayout(0, 2, 5, 5));

            panel.add(new JLabel("Patient ID:"));
            panel.add(patientField);

            panel.add(new JLabel("Doctor ID:"));
            panel.add(doctorField);

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Book Appointment",
                            JOptionPane.OK_CANCEL_OPTION
                    );

            if (result != JOptionPane.OK_OPTION)
                return;

            Patient patient =
                    service.findPatient(
                            patientField.getText().trim()
                    );

            Doctor doctor =
                    service.findDoctor(
                            doctorField.getText().trim()
                    );

            LocalDateTime appointmentTime =
                    LocalDateTime.now().plusDays(1);

            Appointment appointment =
                    service.bookAppointment(
                            patient,
                            doctor,
                            appointmentTime
                    );

            notificationQueue.enqueue(
                    new ReminderNotification(appointment)
            );

            display(
                    "\nAPPOINTMENT BOOKED SUCCESSFULLY\n" +
                    "--------------------------------\n" +
                    "Appointment ID : " +
                    appointment.getAppointmentId() +
                    "\nPatient        : " +
                    patient.getName() +
                    "\nDoctor         : Dr. " +
                    doctor.getName() +
                    "\nTime           : " +
                    appointmentTime
            );

            statusLabel.setText(
                    "Appointment booked successfully"
            );

        } catch (InvalidPatientIdException |
                 InvalidInputException |
                 DuplicateAppointmentException |
                 DoctorUnavailableException e) {

            showError(e.getMessage());
        }
    }

    // ============================================================
    // CANCEL APPOINTMENT
    // ============================================================

    private void cancelAppointment() {

        String appointmentId =
                JOptionPane.showInputDialog(
                        this,
                        "Enter Appointment ID:"
                );

        if (appointmentId == null ||
                appointmentId.trim().isEmpty())
            return;

        try {

            Patient promoted =
                    service.cancelAppointment(
                            appointmentId.trim()
                    );

            String message =
                    "Appointment " +
                    appointmentId +
                    " cancelled successfully.";

            if (promoted != null) {

                message +=
                        "\n\nWaitlisted patient promoted:\n" +
                        promoted.getName();
            }

            display(
                    "\nAPPOINTMENT CANCELLATION\n" +
                    "-------------------------\n" +
                    message
            );

        } catch (InvalidInputException e) {

            showError(e.getMessage());
        }
    }

    // ============================================================
    // SEARCH PATIENT
    // ============================================================

    private void searchPatient() {

        String id =
                JOptionPane.showInputDialog(
                        this,
                        "Enter Patient ID:"
                );

        if (id == null)
            return;

        try {

            Patient patient =
                    service.findPatient(
                            id.trim()
                    );

            display(
                    "\nPATIENT FOUND\n" +
                    "-------------\n" +
                    "ID       : " +
                    patient.getId() +
                    "\nName     : " +
                    patient.getName() +
                    "\nAge      : " +
                    patient.getAge() +
                    "\nContact  : " +
                    patient.getContactNumber() +
                    "\nCategory : " +
                    patient.getCategory() +
                    "\nFee      : Rs." +
                    String.format(
                            "%.2f",
                            patient.calculateConsultationFee()
                    )
            );

        } catch (InvalidPatientIdException e) {

            showError(e.getMessage());
        }
    }

    // ============================================================
    // INVENTORY
    // ============================================================

    private void viewInventory() {

        StringBuilder sb =
                new StringBuilder();

        sb.append("\n");
        sb.append("============= PHARMACY INVENTORY =============\n\n");

        for (Medicine medicine :
                service.getInventory().getAllMedicines()) {

            sb.append(medicine)
                    .append("\n");

            if (medicine.isLowStock()) {

                sb.append(
                        "   *** LOW STOCK ALERT ***\n"
                );
            }

            sb.append(
                    "-----------------------------------------------\n"
            );
        }

        display(sb.toString());
    }

    // ============================================================
    // DISPENSE MEDICINE
    // ============================================================

    private void dispenseMedicine() {

        try {

            JTextField patientField =
                    new JTextField();

            JTextField medicineField =
                    new JTextField();

            JTextField quantityField =
                    new JTextField();

            JPanel panel =
                    new JPanel(
                            new GridLayout(0, 2, 5, 5)
                    );

            panel.add(new JLabel("Patient ID:"));
            panel.add(patientField);

            panel.add(new JLabel("Medicine ID:"));
            panel.add(medicineField);

            panel.add(new JLabel("Quantity:"));
            panel.add(quantityField);

            int result =
                    JOptionPane.showConfirmDialog(
                            this,
                            panel,
                            "Dispense Medicine",
                            JOptionPane.OK_CANCEL_OPTION
                    );

            if (result != JOptionPane.OK_OPTION)
                return;

            Patient patient =
                    service.findPatient(
                            patientField.getText().trim()
                    );

            String medicineId =
                    medicineField.getText().trim();

            int quantity =
                    Integer.parseInt(
                            quantityField.getText().trim()
                    );

            service.dispenseMedicine(
                    patient,
                    medicineId,
                    quantity
            );

            Medicine medicine =
                    service.getInventory()
                            .getMedicine(medicineId);

            if (medicine.isLowStock()) {

                notificationQueue.enqueue(
                        new LowStockNotification(
                                medicine
                        )
                );
            }

            display(
                    "\nMEDICINE DISPENSED\n" +
                    "------------------\n" +
                    "Patient  : " +
                    patient.getName() +
                    "\nMedicine : " +
                    medicine.getName() +
                    "\nQuantity : " +
                    quantity +
                    "\nRemaining Stock : " +
                    medicine.getStockQuantity()
            );

        } catch (NumberFormatException e) {

            showError(
                    "Quantity must be a valid number."
            );

        } catch (InvalidPatientIdException |
                 OutOfStockException e) {

            showError(e.getMessage());
        }
    }

    // ============================================================
    // NOTIFICATIONS
    // ============================================================

    private void showNotifications() {

        NotificationDispatcher dispatcher =
                new NotificationDispatcher(
                        notificationQueue
                );

        dispatcher.start();

        display(
                "\nNOTIFICATION DISPATCHER STARTED\n" +
                "--------------------------------\n" +
                "Appointment reminders and low-stock\n" +
                "notifications are being processed."
        );

        try {

            Thread.sleep(300);

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
    }

    // ============================================================
    // PATIENT REPORT
    // ============================================================

    private void showPatientReport() {

        String report =
                ReportGenerator.patientVisitReport(
                        service
                );

        display(
                "\n" + report
        );
    }

    // ============================================================
    // INVENTORY REPORT
    // ============================================================

    private void showInventoryReport() {

        String report =
                ReportGenerator.inventoryUtilizationReport(
                        service
                );

        display(
                "\n" + report
        );
    }

    // ============================================================
    // MULTITHREADING DEMO
    // ============================================================

    private void runConcurrencyDemo() {

        new Thread(() -> {

            try {

                display(
                        "\nCONCURRENT BOOKING DEMO\n" +
                        "-----------------------\n" +
                        "Starting multiple booking threads..."
                );

                Doctor doctor =
                        service.findDoctor("D1");

                NotificationDispatcher dispatcher =
                        new NotificationDispatcher(
                                notificationQueue
                        );

                dispatcher.start();

                Thread[] bookingThreads =
                        new Thread[4];

                for (int i = 0;
                     i < bookingThreads.length;
                     i++) {

                    Patient patient =
                            new GeneralPatient(
                                    "GUI" + i,
                                    "Demo Patient " + i,
                                    30,
                                    "90000000" + i
                            );

                    try {

                        service.registerPatient(
                                patient
                        );

                    } catch (InvalidInputException ignored) {
                    }

                    bookingThreads[i] =
                            new BookingSimulator(
                                    service,
                                    patient,
                                    doctor,
                                    notificationQueue
                            );

                    bookingThreads[i].start();
                }

                for (Thread thread :
                        bookingThreads) {

                    thread.join();
                }

                notificationQueue.shutdown();

                dispatcher.join();

                display(
                        "\nConcurrency test completed.\n" +
                        "Booking threads executed: 4\n" +
                        "Notification dispatcher completed."
                );

            } catch (Exception e) {

                SwingUtilities.invokeLater(() ->
                        showError(
                                "Concurrency error: " +
                                e.getMessage()
                        )
                );
            }

        }).start();
    }

    // ============================================================
    // UTILITY METHODS
    // ============================================================

    private void display(String text) {

        SwingUtilities.invokeLater(() -> {

            outputArea.append(
                    text + "\n"
            );

            outputArea.setCaretPosition(
                    outputArea.getDocument().getLength()
            );
        });
    }

    private void showError(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "System Error",
                JOptionPane.ERROR_MESSAGE
        );

        statusLabel.setText(
                "Error: " + message
        );
    }

    // ============================================================
    // MAIN
    // ============================================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            try {

                HospitalService service =
                        new HospitalService();

                NotificationQueue queue =
                        new NotificationQueue();

                seedData(service);

                HospitalGUI gui =
                        new HospitalGUI(
                                service,
                                queue
                        );

                gui.setVisible(true);

            } catch (Exception e) {

                JOptionPane.showMessageDialog(
                        null,
                        "Unable to start system:\n" +
                                e.getMessage(),
                        "Startup Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });
    }

    // ============================================================
    // SAMPLE DATA
    // ============================================================

    private static void seedData(
            HospitalService service)
            throws InvalidInputException {

        // Doctors

        service.registerDoctor(
                new Doctor(
                        "D1",
                        "Anita Rao",
                        45,
                        "9000000001",
                        "Cardiology",
                        2
                )
        );

        service.registerDoctor(
                new Doctor(
                        "D2",
                        "Vikram Shah",
                        50,
                        "9000000002",
                        "General Medicine",
                        5
                )
        );

        // Medicines

        service.addMedicine(
                new TabletMedicine(
                        "M1",
                        "Paracetamol",
                        2.5,
                        100,
                        20,
                        500
                )
        );

        service.addMedicine(
                new SyrupMedicine(
                        "M2",
                        "Cough Syrup",
                        45.0,
                        15,
                        10,
                        10
                )
        );

        service.addMedicine(
                new InjectableMedicine(
                        "M3",
                        "Insulin",
                        120.0,
                        8,
                        5,
                        true
                )
        );

        // Patients

        service.registerPatient(
                new GeneralPatient(
                        "P1",
                        "Ravi Kumar",
                        34,
                        "9111111111"
                )
        );

        service.registerPatient(
                new SeniorCitizenPatient(
                        "P2",
                        "Lakshmi Iyer",
                        67,
                        "9222222222"
                )
        );

        service.registerPatient(
                new InsuredPatient(
                        "P3",
                        "Meera Nair",
                        29,
                        "9333333333",
                        "StarHealth",
                        0.30
                )
        );
    }
}
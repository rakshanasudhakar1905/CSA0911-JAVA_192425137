package hospital;

import java.time.LocalDateTime;

/** Represents a booked appointment linking a Patient to a Doctor at a given time. */
public class Appointment {
    private static int counter = 1000;

    private final String appointmentId;
    private final Patient patient;
    private final Doctor doctor;
    private final LocalDateTime scheduledTime;
    private String status; // BOOKED, CANCELLED, COMPLETED

    public Appointment(Patient patient, Doctor doctor, LocalDateTime scheduledTime) {
        this.appointmentId = "APT" + (++counter);
        this.patient = patient;
        this.doctor = doctor;
        this.scheduledTime = scheduledTime;
        this.status = "BOOKED";
    }

    public String getAppointmentId() { return appointmentId; }
    public Patient getPatient() { return patient; }
    public Doctor getDoctor() { return doctor; }
    public LocalDateTime getScheduledTime() { return scheduledTime; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("%s | %s with Dr. %s at %s [%s]",
                appointmentId, patient.getName(), doctor.getName(), scheduledTime, status);
    }
}

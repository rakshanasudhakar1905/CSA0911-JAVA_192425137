package hospital;

public class InjectableMedicine extends Medicine {
    private final boolean requiresRefrigeration;

    public InjectableMedicine(String id, String name, double unitPrice, int stockQuantity,
                               int reorderThreshold, boolean requiresRefrigeration) {
        super(id, name, unitPrice, stockQuantity, reorderThreshold);
        this.requiresRefrigeration = requiresRefrigeration;
    }

    @Override
    public String getDosageInstructions() {
        return "Administer under supervision" + (requiresRefrigeration ? " (store refrigerated)" : "");
    }

    @Override
    public String getMedicineType() {
        return "Injectable";
    }
}

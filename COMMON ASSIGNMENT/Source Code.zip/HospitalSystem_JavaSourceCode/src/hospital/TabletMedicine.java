package hospital;

public class TabletMedicine extends Medicine {
    private final int mgPerTablet;

    public TabletMedicine(String id, String name, double unitPrice, int stockQuantity,
                           int reorderThreshold, int mgPerTablet) {
        super(id, name, unitPrice, stockQuantity, reorderThreshold);
        this.mgPerTablet = mgPerTablet;
    }

    @Override
    public String getDosageInstructions() {
        return "Take 1 tablet (" + mgPerTablet + "mg) twice daily after food";
    }

    @Override
    public String getMedicineType() {
        return "Tablet";
    }
}

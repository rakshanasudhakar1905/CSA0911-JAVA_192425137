package hospital;

import hospital.exceptions.*;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Core service layer. Holds every Collection Framework structure required by CO2:
 *  - ArrayList<Patient>            : ordered patient registry
 *  - HashMap<String, Doctor>       : O(1) doctor lookup by ID
 *  - HashSet<String>               : fast duplicate-ID checks
 *  - ArrayList<Appointment>        : appointment history (traversed via ListIterator)
 *  - Hashtable<String, Medicine>   : synchronized pharmacy stock (inside Inventory)
 */
public class HospitalService {
    private final List<Patient> patients = new ArrayList<>();
    private final Map<String, Doctor> doctors = new HashMap<>();
    private final Set<String> registeredIds = new HashSet<>();
    private final List<Appointment> appointments = new ArrayList<>();
    private final Inventory inventory = new Inventory();

    // ---------- Registration ----------

    public void registerPatient(Patient patient) throws InvalidInputException {
        if (registeredIds.contains(patient.getId())) {
            throw new InvalidInputException("Patient ID " + patient.getId() + " is already registered.");
        }
        patients.add(patient);
        registeredIds.add(patient.getId());
    }

    public void registerDoctor(Doctor doctor) throws InvalidInputException {
        if (doctors.containsKey(doctor.getId())) {
            throw new InvalidInputException("Doctor ID " + doctor.getId() + " is already registered.");
        }
        doctors.put(doctor.getId(), doctor);
    }

    public void addMedicine(Medicine medicine) {
        inventory.addMedicine(medicine);
    }

    public Inventory getInventory() { return inventory; }
    public List<Patient> getPatients() { return patients; }
    public Map<String, Doctor> getDoctors() { return doctors; }
    public List<Appointment> getAppointments() { return appointments; }

    // ---------- Search (uses Iterator explicitly, CO2) ----------

    public Patient findPatient(String patientId) throws InvalidPatientIdException {
        Iterator<Patient> it = patients.iterator();
        while (it.hasNext()) {
            Patient p = it.next();
            if (p.getId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        throw new InvalidPatientIdException("No patient found with ID: " + patientId);
    }

    public Doctor findDoctor(String doctorId) throws InvalidInputException {
        Doctor d = doctors.get(doctorId);
        if (d == null) {
            throw new InvalidInputException("No doctor found with ID: " + doctorId);
        }
        return d;
    }

    // ---------- Booking / cancellation ----------

    /**
     * Books an appointment. Thread-safe: relies on Doctor.reserveSlot(), which is
     * synchronized, so two BookingSimulator threads racing for the last slot cannot
     * both succeed. If the doctor is full the patient is waitlisted instead of
     * silently failing.
     */
    public synchronized Appointment bookAppointment(Patient patient, Doctor doctor, LocalDateTime time)
            throws DuplicateAppointmentException, DoctorUnavailableException {
        for (Appointment existing : doctor.getBookedAppointments()) {
            if (existing.getPatient().getId().equals(patient.getId())
                    && existing.getStatus().equals("BOOKED")) {
                throw new DuplicateAppointmentException(
                        patient.getName() + " already has an active appointment with Dr. " + doctor.getName());
            }
        }
        if (!doctor.reserveSlot()) {
            doctor.addToWaitlist(patient);
            throw new DoctorUnavailableException(
                    "Dr. " + doctor.getName() + " is fully booked; " + patient.getName() + " added to waitlist.");
        }
        Appointment appointment = new Appointment(patient, doctor, time);
        doctor.getBookedAppointments().add(appointment);
        appointments.add(appointment);
        return appointment;
    }

    /** Cancelling frees the slot and, if someone is waiting, auto-promotes them. */
    public synchronized Patient cancelAppointment(String appointmentId) throws InvalidInputException {
        ListIterator<Appointment> it = appointments.listIterator();
        while (it.hasNext()) {
            Appointment a = it.next();
            if (a.getAppointmentId().equalsIgnoreCase(appointmentId) && a.getStatus().equals("BOOKED")) {
                a.setStatus("CANCELLED");
                a.getDoctor().releaseSlot();
                Patient promoted = a.getDoctor().pollWaitlist();
                return promoted; // may be null if nobody was waiting
            }
        }
        throw new InvalidInputException("No active appointment found with ID: " + appointmentId);
    }

    // ---------- Pharmacy ----------

    public void dispenseMedicine(Patient patient, String medicineId, int quantity) throws OutOfStockException {
        inventory.dispense(medicineId, quantity);
        patient.prescribeMedicine(medicineId);
    }
}

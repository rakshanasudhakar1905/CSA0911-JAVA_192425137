package hospital;

import java.util.List;
import java.util.Collections;
import java.util.ArrayList;

/**
 * Consumer thread: continuously drains the shared NotificationQueue and "dispatches"
 * (prints + logs) each notification. Runs at a lower thread priority than booking,
 * since alerting is important but not as time-critical as slot reservation.
 */
public class NotificationDispatcher extends Thread {
    private final NotificationQueue queue;
    private final List<String> dispatchLog = Collections.synchronizedList(new ArrayList<>());

    public NotificationDispatcher(NotificationQueue queue) {
        super("NotificationDispatcher");
        this.queue = queue;
        setPriority(Thread.NORM_PRIORITY - 1);
    }

    public List<String> getDispatchLog() {
        return dispatchLog;
    }

    @Override
    public void run() {
        try {
            Notification notification;
            while ((notification = queue.dequeue()) != null) {
                String message = notification.send();
                dispatchLog.add(message);
                System.out.println(message);
                Thread.sleep(50); // simulate dispatch latency
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("NotificationDispatcher interrupted, shutting down.");
        }
    }
}

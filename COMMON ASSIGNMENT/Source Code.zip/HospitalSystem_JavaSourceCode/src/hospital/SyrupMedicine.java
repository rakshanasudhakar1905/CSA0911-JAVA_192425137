package hospital;

public class SyrupMedicine extends Medicine {
    private final int mlPerDose;

    public SyrupMedicine(String id, String name, double unitPrice, int stockQuantity,
                          int reorderThreshold, int mlPerDose) {
        super(id, name, unitPrice, stockQuantity, reorderThreshold);
        this.mlPerDose = mlPerDose;
    }

    @Override
    public String getDosageInstructions() {
        return "Take " + mlPerDose + "ml three times daily";
    }

    @Override
    public String getMedicineType() {
        return "Syrup";
    }
}

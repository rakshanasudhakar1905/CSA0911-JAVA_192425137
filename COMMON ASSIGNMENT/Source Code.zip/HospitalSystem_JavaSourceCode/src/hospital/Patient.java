package hospital;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstract Patient class. Different patient categories (General, SeniorCitizen,
 * Insured) override calculateConsultationFee() to demonstrate run-time polymorphism —
 * fee waivers/discounts are resolved dynamically based on the actual object type.
 */
public abstract class Patient extends Person {
    private final List<String> prescribedMedicineIds = new ArrayList<>();
    private static final double BASE_CONSULTATION_FEE = 500.0;

    public Patient(String id, String name, int age, String contactNumber) {
        super(id, name, age, contactNumber);
    }

    public static double getBaseConsultationFee() {
        return BASE_CONSULTATION_FEE;
    }

    public List<String> getPrescribedMedicineIds() {
        return prescribedMedicineIds;
    }

    public void prescribeMedicine(String medicineId) {
        prescribedMedicineIds.add(medicineId);
    }

    /** Polymorphic hook: each patient category computes its own fee. */
    public abstract double calculateConsultationFee();

    /** Polymorphic hook: each patient category may have a distinct patient class label. */
    public abstract String getCategory();

    @Override
    public String getSummary() {
        return String.format("[%s] %s (Age %d, %s) - Fee: Rs.%.2f",
                getCategory(), getName(), getAge(), getId(), calculateConsultationFee());
    }
}

package hospital;

import hospital.exceptions.*;

import java.time.LocalDateTime;
import java.util.Scanner;

/**
 * Menu-driven entry point. Seeds sample data, then presents a console menu for
 * registration, booking, search/update, dispensing, reports, and a demo of the
 * multithreaded booking + notification subsystem.
 */
public class Main {
    private static final HospitalService service = new HospitalService();
    private static final NotificationQueue notificationQueue = new NotificationQueue();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws InvalidInputException {
        seedData();
        boolean running = true;
        while (running) {
            printMenu();
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1": registerPatientFlow(); break;
                    case "2": bookAppointmentFlow(); break;
                    case "3": cancelAppointmentFlow(); break;
                    case "4": searchUpdatePatientFlow(); break;
                    case "5": dispenseMedicineFlow(); break;
                    case "6": viewInventoryFlow(); break;
                    case "7": System.out.println(ReportGenerator.patientVisitReport(service)); break;
                    case "8": System.out.println(ReportGenerator.inventoryUtilizationReport(service)); break;
                    case "9": runConcurrencyDemo(); break;
                    case "0": running = false; break;
                    default: System.out.println("Invalid option. Please choose 0-9.");
                }
            } catch (InvalidInputException | InvalidPatientIdException | OutOfStockException
                     | DuplicateAppointmentException | DoctorUnavailableException e) {
                // Every user-facing exception is caught here so a bad menu action
                // never terminates the program (CO3: robustness requirement).
                System.out.println("Error: " + e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Error: please enter a valid number.");
            }
        }
        notificationQueue.shutdown();
        System.out.println("Goodbye.");
    }

    private static void printMenu() {
        System.out.println("\n===== SMART HOSPITAL SYSTEM =====");
        System.out.println("1. Register Patient");
        System.out.println("2. Book Appointment");
        System.out.println("3. Cancel Appointment");
        System.out.println("4. Search / Update Patient");
        System.out.println("5. Dispense Medicine");
        System.out.println("6. View Inventory & Stock Alerts");
        System.out.println("7. Patient Visit Report");
        System.out.println("8. Inventory Utilization Report");
        System.out.println("9. Run Concurrent Booking + Notification Demo");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    private static void registerPatientFlow() throws InvalidInputException {
        System.out.print("Patient ID: ");
        String id = requireNonEmpty(sc.nextLine());
        System.out.print("Name: ");
        String name = requireNonEmpty(sc.nextLine());
        System.out.print("Age: ");
        int age = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Contact: ");
        String contact = requireNonEmpty(sc.nextLine());
        System.out.print("Category (1=General, 2=Senior Citizen, 3=Insured): ");
        String cat = sc.nextLine().trim();

        Patient patient;
        if (cat.equals("2")) {
            patient = new SeniorCitizenPatient(id, name, age, contact);
        } else if (cat.equals("3")) {
            System.out.print("Insurance provider: ");
            String provider = sc.nextLine().trim();
            System.out.print("Co-pay fraction (e.g. 0.3 for 30%): ");
            double coPay = Double.parseDouble(sc.nextLine().trim());
            patient = new InsuredPatient(id, name, age, contact, provider, coPay);
        } else {
            patient = new GeneralPatient(id, name, age, contact);
        }
        service.registerPatient(patient);
        System.out.println("Registered: " + patient.getSummary());
    }

    private static void bookAppointmentFlow() throws InvalidPatientIdException, InvalidInputException,
            DuplicateAppointmentException, DoctorUnavailableException {
        System.out.print("Patient ID: ");
        Patient patient = service.findPatient(sc.nextLine().trim());
        System.out.print("Doctor ID: ");
        Doctor doctor = service.findDoctor(sc.nextLine().trim());
        Appointment appointment = service.bookAppointment(patient, doctor, LocalDateTime.now().plusDays(1));
        notificationQueue.enqueue(new ReminderNotification(appointment));
        System.out.println("Booked: " + appointment);
    }

    private static void cancelAppointmentFlow() throws InvalidInputException {
        System.out.print("Appointment ID: ");
        Patient promoted = service.cancelAppointment(sc.nextLine().trim());
        System.out.println("Cancelled.");
        if (promoted != null) {
            System.out.println(promoted.getName() + " was promoted from the waitlist into the freed slot.");
        }
    }

    private static void searchUpdatePatientFlow() throws InvalidPatientIdException {
        System.out.print("Patient ID: ");
        Patient patient = service.findPatient(sc.nextLine().trim());
        System.out.println("Found: " + patient.getSummary());
        System.out.print("Update contact number? (leave blank to skip): ");
        String newContact = sc.nextLine().trim();
        if (!newContact.isEmpty()) {
            patient.setContactNumber(newContact);
            System.out.println("Contact updated.");
        }
    }

    private static void dispenseMedicineFlow() throws InvalidPatientIdException, OutOfStockException {
        System.out.print("Patient ID: ");
        Patient patient = service.findPatient(sc.nextLine().trim());
        System.out.print("Medicine ID: ");
        String medId = sc.nextLine().trim();
        System.out.print("Quantity: ");
        int qty = Integer.parseInt(sc.nextLine().trim());
        service.dispenseMedicine(patient, medId, qty);
        System.out.println("Dispensed " + qty + " unit(s) of " + medId + " to " + patient.getName());
        Medicine m = service.getInventory().getMedicine(medId);
        if (m.isLowStock()) {
            notificationQueue.enqueue(new LowStockNotification(m));
            System.out.println("(Low stock alert queued for " + m.getName() + ")");
        }
    }

    private static void viewInventoryFlow() {
        for (Medicine m : service.getInventory().getAllMedicines()) {
            System.out.println(m);
        }
    }

    /** Spins up several booking threads (producers) and one dispatcher thread (consumer). */
    private static void runConcurrencyDemo() throws InvalidPatientIdException, InvalidInputException {
        System.out.println("Launching concurrent booking simulation...");
        NotificationDispatcher dispatcher = new NotificationDispatcher(notificationQueue);
        dispatcher.start();

        Doctor doctor = service.findDoctor("D1");
        Thread[] bookers = new Thread[4];
        for (int i = 0; i < bookers.length; i++) {
            Patient p = new GeneralPatient("TEMP" + i, "Demo Patient " + i, 30, "0000000000");
            try {
                service.registerPatient(p);
            } catch (InvalidInputException ignored) { /* demo IDs are unique */ }
            bookers[i] = new BookingSimulator(service, p, doctor, notificationQueue);
        }
        for (Thread t : bookers) t.start();
        for (Thread t : bookers) {
            try { t.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        notificationQueue.shutdown();
        try { dispatcher.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        System.out.println("Concurrency demo complete. " + dispatcher.getDispatchLog().size() + " notifications dispatched.");
    }

    private static String requireNonEmpty(String s) throws InvalidInputException {
        if (s == null || s.trim().isEmpty()) {
            throw new InvalidInputException("Field cannot be empty.");
        }
        return s.trim();
    }

    private static void seedData() throws InvalidInputException {
        service.registerDoctor(new Doctor("D1", "Anita Rao", 45, "9000000001", "Cardiology", 2));
        service.registerDoctor(new Doctor("D2", "Vikram Shah", 50, "9000000002", "General Medicine", 5));

        service.addMedicine(new TabletMedicine("M1", "Paracetamol", 2.5, 100, 20, 500));
        service.addMedicine(new SyrupMedicine("M2", "Cough Syrup", 45.0, 15, 10, 10));
        service.addMedicine(new InjectableMedicine("M3", "Insulin", 120.0, 8, 5, true));

        try {
            service.registerPatient(new GeneralPatient("P1", "Ravi Kumar", 34, "9111111111"));
            service.registerPatient(new SeniorCitizenPatient("P2", "Lakshmi Iyer", 67, "9222222222"));
            service.registerPatient(new InsuredPatient("P3", "Meera Nair", 29, "9333333333", "StarHealth", 0.3));
        } catch (InvalidInputException ignored) { }
    }
}

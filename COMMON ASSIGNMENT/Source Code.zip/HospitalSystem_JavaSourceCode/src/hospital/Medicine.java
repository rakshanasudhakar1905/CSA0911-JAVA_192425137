package hospital;

/**
 * Abstract Medicine class. Subclasses (Tablet, Syrup, Injectable) override
 * getDosageInstructions() so dosage rules adapt at run time based on the
 * actual medicine type — a second example of polymorphism in the system.
 */
public abstract class Medicine {
    private final String id;
    private final String name;
    private double unitPrice;
    private int stockQuantity;
    private int reorderThreshold;

    public Medicine(String id, String name, double unitPrice, int stockQuantity, int reorderThreshold) {
        this.id = id;
        this.name = name;
        this.unitPrice = unitPrice;
        this.stockQuantity = stockQuantity;
        this.reorderThreshold = reorderThreshold;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }
    public synchronized int getStockQuantity() { return stockQuantity; }
    public int getReorderThreshold() { return reorderThreshold; }

    /** Synchronized: shared inventory must not be corrupted by concurrent threads. */
    public synchronized void deduct(int quantity) {
        stockQuantity -= quantity;
    }

    public synchronized void restock(int quantity) {
        stockQuantity += quantity;
    }

    public synchronized boolean isLowStock() {
        return stockQuantity <= reorderThreshold;
    }

    public abstract String getDosageInstructions();
    public abstract String getMedicineType();

    @Override
    public String toString() {
        return String.format("[%s] %s (%s) - Rs.%.2f | Stock: %d | %s",
                id, name, getMedicineType(), unitPrice, stockQuantity, getDosageInstructions());
    }
}

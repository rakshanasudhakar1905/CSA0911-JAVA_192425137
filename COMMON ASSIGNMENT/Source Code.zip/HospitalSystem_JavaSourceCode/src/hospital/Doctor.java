package hospital;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * Represents a doctor along with their daily appointment slots and a waitlist
 * for patients who could not be accommodated when all slots were full.
 */
public class Doctor extends Person {
    private final String specialization;
    private int availableSlots;
    private final List<Appointment> bookedAppointments = new LinkedList<>();
    private final Queue<Patient> waitlist = new LinkedList<>();

    public Doctor(String id, String name, int age, String contactNumber,
                   String specialization, int availableSlots) {
        super(id, name, age, contactNumber);
        this.specialization = specialization;
        this.availableSlots = availableSlots;
    }

    public String getSpecialization() { return specialization; }
    public synchronized int getAvailableSlots() { return availableSlots; }
    public List<Appointment> getBookedAppointments() { return bookedAppointments; }
    public Queue<Patient> getWaitlist() { return waitlist; }

    /** Synchronized so concurrent booking threads cannot both grab the last slot. */
    public synchronized boolean reserveSlot() {
        if (availableSlots > 0) {
            availableSlots--;
            return true;
        }
        return false;
    }

    public synchronized void releaseSlot() {
        availableSlots++;
    }

    public synchronized void addToWaitlist(Patient patient) {
        waitlist.add(patient);
    }

    public synchronized Patient pollWaitlist() {
        return waitlist.poll();
    }

    @Override
    public String getSummary() {
        return String.format("Dr. %s [%s] (%s) - Slots left: %d, Waitlist: %d",
                getName(), getId(), specialization, availableSlots, waitlist.size());
    }
}

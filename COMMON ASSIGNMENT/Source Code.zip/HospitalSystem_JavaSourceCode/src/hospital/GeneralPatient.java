package hospital;

/** Standard patient category — pays the full base consultation fee. */
public class GeneralPatient extends Patient {
    public GeneralPatient(String id, String name, int age, String contactNumber) {
        super(id, name, age, contactNumber);
    }

    @Override
    public double calculateConsultationFee() {
        return getBaseConsultationFee();
    }

    @Override
    public String getCategory() {
        return "General";
    }
}

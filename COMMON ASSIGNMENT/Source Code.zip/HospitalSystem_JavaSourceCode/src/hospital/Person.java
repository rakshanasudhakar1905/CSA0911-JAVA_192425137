package hospital;

/**
 * Abstract base class representing any human actor in the system.
 * Encapsulates the common attributes shared by Patient and Doctor.
 */
public abstract class Person {
    private final String id;
    private String name;
    private int age;
    private String contactNumber;

    public Person(String id, String name, int age, String contactNumber) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.contactNumber = contactNumber;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    /** Every concrete Person must describe itself for reports/menus. */
    public abstract String getSummary();

    @Override
    public String toString() {
        return getSummary();
    }
}

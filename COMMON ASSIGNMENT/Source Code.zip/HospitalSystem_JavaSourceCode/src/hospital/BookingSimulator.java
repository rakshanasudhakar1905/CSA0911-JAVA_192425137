package hospital;

import hospital.exceptions.DoctorUnavailableException;
import hospital.exceptions.DuplicateAppointmentException;

import java.time.LocalDateTime;

/**
 * Producer thread: simulates a patient concurrently attempting to book an
 * appointment slot with a given doctor. Runs at a higher priority than the
 * notification dispatcher since booking is the time-critical path; slot
 * reservation itself is made safe via Doctor.reserveSlot() (synchronized).
 */
public class BookingSimulator extends Thread {
    private final HospitalService service;
    private final Patient patient;
    private final Doctor doctor;
    private final NotificationQueue notificationQueue;

    public BookingSimulator(HospitalService service, Patient patient, Doctor doctor,
                             NotificationQueue notificationQueue) {
        super("Booking-" + patient.getId());
        this.service = service;
        this.patient = patient;
        this.doctor = doctor;
        this.notificationQueue = notificationQueue;
        setPriority(Thread.NORM_PRIORITY + 1);
    }

    @Override
    public void run() {
        try {
            Appointment appointment = service.bookAppointment(patient, doctor, LocalDateTime.now().plusDays(1));
            notificationQueue.enqueue(new ReminderNotification(appointment));
            System.out.println(Thread.currentThread().getName() + " booked " + appointment.getAppointmentId());
        } catch (DuplicateAppointmentException e) {
            System.out.println(Thread.currentThread().getName() + " failed: " + e.getMessage());
        } catch (DoctorUnavailableException e) {
            System.out.println(Thread.currentThread().getName() + " waitlisted: " + e.getMessage());
        }
    }
}

package hospital;

import hospital.exceptions.OutOfStockException;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

/**
 * Wraps the pharmacy stock. Hashtable is used deliberately (rather than HashMap)
 * because its methods are internally synchronized, giving thread-safe access when
 * multiple booking/dispatch threads read or update stock concurrently.
 */
public class Inventory {
    private final Hashtable<String, Medicine> medicines = new Hashtable<>();

    public void addMedicine(Medicine medicine) {
        medicines.put(medicine.getId(), medicine);
    }

    public Medicine getMedicine(String medicineId) {
        return medicines.get(medicineId);
    }

    public Collection<Medicine> getAllMedicines() {
        return medicines.values();
    }

    /** Deducts stock for a prescription; throws if insufficient quantity is available. */
    public synchronized void dispense(String medicineId, int quantity) throws OutOfStockException {
        Medicine medicine = medicines.get(medicineId);
        if (medicine == null) {
            throw new OutOfStockException("Medicine ID " + medicineId + " does not exist in inventory.");
        }
        if (medicine.getStockQuantity() < quantity) {
            throw new OutOfStockException("Insufficient stock for " + medicine.getName()
                    + ". Requested: " + quantity + ", Available: " + medicine.getStockQuantity());
        }
        medicine.deduct(quantity);
    }

    /** Uses an explicit Iterator (as required by CO2) to find every medicine below its reorder threshold. */
    public Iterator<Medicine> lowStockIterator() {
        java.util.List<Medicine> lowStock = new java.util.ArrayList<>();
        for (Map.Entry<String, Medicine> entry : medicines.entrySet()) {
            if (entry.getValue().isLowStock()) {
                lowStock.add(entry.getValue());
            }
        }
        return lowStock.iterator();
    }

    public int size() {
        return medicines.size();
    }
}

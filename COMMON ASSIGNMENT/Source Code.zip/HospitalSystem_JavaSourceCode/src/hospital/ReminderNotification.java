package hospital;

public class ReminderNotification extends Notification {
    private final Appointment appointment;

    public ReminderNotification(Appointment appointment) {
        super();
        this.appointment = appointment;
    }

    @Override
    public String send() {
        return String.format("[REMINDER] Dear %s, you have an appointment with Dr. %s at %s.",
                appointment.getPatient().getName(),
                appointment.getDoctor().getName(),
                appointment.getScheduledTime());
    }
}

package hospital;

/** Senior citizens (age 60+) receive a 20% consultation-fee waiver. */
public class SeniorCitizenPatient extends Patient {
    private static final double SENIOR_DISCOUNT_RATE = 0.20;

    public SeniorCitizenPatient(String id, String name, int age, String contactNumber) {
        super(id, name, age, contactNumber);
    }

    @Override
    public double calculateConsultationFee() {
        return getBaseConsultationFee() * (1 - SENIOR_DISCOUNT_RATE);
    }

    @Override
    public String getCategory() {
        return "Senior Citizen";
    }
}

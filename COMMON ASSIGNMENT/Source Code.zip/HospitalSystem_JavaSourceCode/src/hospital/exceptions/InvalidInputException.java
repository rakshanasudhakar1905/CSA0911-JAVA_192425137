package hospital.exceptions;

/** Thrown when menu / field input fails basic validation (empty, wrong type, out of range). */
public class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}

package hospital.exceptions;

/** Thrown when a requested medicine quantity exceeds available stock. */
public class OutOfStockException extends Exception {
    public OutOfStockException(String message) {
        super(message);
    }
}

package hospital.exceptions;

/** Thrown when a patient tries to book more than one active appointment with the same doctor. */
public class DuplicateAppointmentException extends Exception {
    public DuplicateAppointmentException(String message) {
        super(message);
    }
}

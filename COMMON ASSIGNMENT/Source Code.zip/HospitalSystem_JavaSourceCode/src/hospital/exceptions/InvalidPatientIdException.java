package hospital.exceptions;

/** Thrown when a patient ID supplied by the user does not exist in the system. */
public class InvalidPatientIdException extends Exception {
    public InvalidPatientIdException(String message) {
        super(message);
    }
}

package hospital.exceptions;

/** Thrown when a doctor has no free slots and the patient has already been placed on the waitlist. */
public class DoctorUnavailableException extends Exception {
    public DoctorUnavailableException(String message) {
        super(message);
    }
}

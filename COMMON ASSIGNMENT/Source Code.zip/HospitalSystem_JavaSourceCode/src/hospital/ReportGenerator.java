package hospital;

import java.util.Iterator;
import java.util.List;

/** Generates the patient-visit report and the pharmacy inventory-utilization report. */
public class ReportGenerator {

    public static String patientVisitReport(HospitalService service) {
        StringBuilder sb = new StringBuilder();
        sb.append("===== PATIENT VISIT REPORT =====\n");
        List<Appointment> appointments = service.getAppointments();
        int completed = 0, cancelled = 0, booked = 0;
        Iterator<Appointment> it = appointments.iterator();
        while (it.hasNext()) {
            Appointment a = it.next();
            sb.append(a).append("\n");
            switch (a.getStatus()) {
                case "COMPLETED": completed++; break;
                case "CANCELLED": cancelled++; break;
                default: booked++;
            }
        }
        sb.append(String.format("Total: %d | Booked: %d | Completed: %d | Cancelled: %d%n",
                appointments.size(), booked, completed, cancelled));
        return sb.toString();
    }

    public static String inventoryUtilizationReport(HospitalService service) {
        StringBuilder sb = new StringBuilder();
        sb.append("===== PHARMACY INVENTORY REPORT =====\n");
        for (Medicine m : service.getInventory().getAllMedicines()) {
            sb.append(m).append("\n");
        }
        sb.append("--- Low Stock Alerts ---\n");
        Iterator<Medicine> lowStockIt = service.getInventory().lowStockIterator();
        boolean any = false;
        while (lowStockIt.hasNext()) {
            any = true;
            sb.append(lowStockIt.next()).append("\n");
        }
        if (!any) sb.append("None. All stock levels are healthy.\n");
        return sb.toString();
    }
}
